//console.log('Hello!!!');
//한 줄 주석
/**
 * 여러 줄 주석
 */

//변수 선언, 사용
// var num = 100;
// console.log(typeof num);
// num = '안녕';
// console.log(typeof num);

//컴파일 언어 : 데이터형 매우 엄격
//인터프리터 언어 : 문법적으로 느슨한것 요구

//var : 여러 큰 스코프에서 공유하기 위해 최상위 변수 사용
//let : 작은 스코프 : 로컬변수
//const : 상수값으로 사용

// const a = 10;
// a = 'hello';
// console.log(a)

//데이터 타입(자료형)

//숫자형(number)
let intNum = 10;
let floatNum = 3.14;

console.log(typeof intNum);//number
console.log(typeof floatNum);//number

//문자형(string)
let sinS = 'single';
console.log(sinS);
let doubleS = "double";

console.log(typeof sinS);
console.log(typeof doubleS);

/**
 * Template Literal
 *  1. newLine -> \n
 *  2. tab -> \t
 *  3. 백슬러시 -> \\
 */

const kosa1 = '홍길동\t박길동';
console.log(kosa1);

const kosa2 = `김길동
  !!!
    조길동    한길동 

    $$
`;

console.log(kosa2);

const groupName = 'kosa';
console.log(groupName + ' 홍길동');
console.log(`${groupName} :  박길동`);

//논리형(boolean)
/**
 * false
 *  => String : 빈문자열 ''
 *  => 값이 없는 경우
 *  => 0
 */

//console.log(!!false);
console.log(!!'');
console.log(!!0);
console.log(!!undefined);
console.log(!!null);
console.log(!!'0');
console.log(!!{});
console.log(!![]);

//undefined
let emptyVar;
console.log(typeof undefined);

//null
let nullVar = null;
console.log(typeof null);

//객체(object)
let person = {
  name : '홍길동',
  age : 20
}

console.log(typeof person);

//함수(function)
let fun = function(){};
console.log(typeof fun);


let str = '"s"tring';
console.log(str);