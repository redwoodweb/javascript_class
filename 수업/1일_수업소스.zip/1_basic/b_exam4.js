console.log( 5 == 5);
console.log( 5 == '5');
console.log( 5 === '5');

//for ~ in ,  for ~ of
const kosaMember = ['김길동', '박길동', '홍길동'];

for(let key in kosaMember){
  console.log(`${key} : ${kosaMember[key]}`);
}

console.log('=======================================');

for(let value of kosaMember){
  console.log(value);
}

console.log('' || 'Dog');