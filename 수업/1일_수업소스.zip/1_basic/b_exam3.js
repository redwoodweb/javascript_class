/**
 * 타입변환(형변환)
 *  1) 암묵적
 *  2) 명시적
 */

//암묵적
let money = 10;
let test = '$'+money ;
console.log(typeof test);
console.log(test);

//명시적
let age = 20;
let stringAge = age.toString();
console.log(typeof stringAge);
console.log(stringAge);

//문자열 => number : eval(), Number(), parseInt(), parseFloat()
let num = '100안녕';
num = parseInt(num);
let result = num + 100;
console.log(result);

/**
 * Hoisting(호이스팅)
 *  - 모든 변수 선언문이 코드의 최상단으로 이동되는 것처럼 느껴지는 현상 *  
 */


// console.log(name2);
// name2 = '홍길동';
// let name2;

console.log(kim);
let kim = '김씨';
