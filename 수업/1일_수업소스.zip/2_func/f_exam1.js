// console.log(add(10, 20));
// console.log(add2(100, 200));


//선언적 함수
function add(a, b){
  let sum = a + b;
  return sum;
}

//익명함수
let add2 = function(a, b){
  let sum = a + b;
  return sum;
}

console.log(typeof add2);

// add2    VS   add2()
let plus = add2; //함수를 할당 : 주소값을 할당 => plus 함수
let plus2 = add2(10, 30);//함수를 호출 => 리턴값을 할당

console.log(plus(50, 20));

//함수의 파라미터에 함수를 전달할수 있다.
let foo = function(func){
  if(typeof func === 'function'){
    func();
  }  
}

foo(function(){
  console.log('파라미티에 함수를 전달하는 예제');
});

//함수가 함수를 리턴할 수 있다.
let foo2 = function(){
  return function(){
    console.log('함수를 리턴하는 예제');
  }
}

let box = foo2();
box();

//함수의 파라미터에(plus or minus) 호출
//plus -> plus 기능을 하는 함수를 리턴
//minus -> minus 기능을 함수를 리턴
//리턴 받은 해당 함수를 호출해서 결과값을 출력

// function call(mode){
//   if(mode === 'plus'){
//     return function(left, right){
//       return left + right;
//     }
//   }else if(mode === 'minus'){
//     return function(left, right){
//       return left - right;
//     }
//   }
// }

function call(mode){
  let obj = {
    'plus' : function(left, right){
      return left + right;
    },
    'minus' : function(left, right){
      return left - right;
    }    
  }
  return obj[mode];  
}

let func2 = call('plus');
console.log(func2(50, 30));

function sortDesending(a, b){
  return b - a;
  // if(a > b){
  //   return -1;
  // }else if(a < b){
  //   return 1;
  // }else{
  //   return 0;
  // }
}

let arr = [42, 32, 12, 88, 53];
console.log(arr.sort(sortDesending));

//즉시실행함수 : 함수 정의와 동시에 호출
(function(a, b){
  console.log(a+b);
})(10, 5);