/**
 * 함수 클로저
 * -> 함수 호출 이후에도 함수의 실행 컨텍스트 영역을 유지
 */

function outerFunc(){
  let x = 10;
  let innerFunc = function(){
    console.log(x);
  }

  return innerFunc;
}

let inner = outerFunc();
inner();

//데이터 캐싱
function cashFunction(newNumb){
  //아주 오래 소요하는 작엉
  let number = 10 * 10;
  return number * newNumb;
}

console.log(cashFunction(10));
console.log(cashFunction(20));


function cashFunction2(){
  //아주 오래 소요하는 작엉
  let number = 10 * 10;

  function innerCashFunction(newNumb){
    return number * newNumb;
  }

  return innerCashFunction;
}

const runner = cashFunction2();
console.log(runner(30));
console.log(runner(40));

