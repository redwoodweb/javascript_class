/**
 * 자바스크립트 객체
 * 1) 사용자 정의 객체
 *   1. Object 2. 객체 리터럴, 3. 생성자함수(프로토타입)
 * 2) 내장객체
 *   1. 코아객체 : string, number, math, array
 *   2. 브라우저 객체 : window, document, history
 *   3. DOM 객체 : 문서내 모든 요소 객체화 : div, form, p
 */

//자바스크립트 객체는 동적으로 프로퍼티를 추가/삭제할 수 있다.
let obj = new Object();

obj.name = '홍길동';
obj.age = 20;

console.log(`이름: ${obj.name}`);

//함수는 1급 객체이다.
function add(a, b){
  let sum = a + b;
  return sum;
}
console.log(typeof add);
console.log(add instanceof Object);

add.result = add(10, 20);
console.log(`결과: ${add.result}`);

//리터럴 형식으로 객체 사용 => 1객의 객체를 생성해서 사용하는 경우
let obj2 = {
  name: '김길동',
  age: 30,
  display: function(){
    console.log(this.name);
  }
}

obj2.display();
console.log(obj2.age);
console.log(obj2['age']);

//퀴즈> 리터럴 형식으로 빈 객체를 생성 후
//      동적 프로퍼티와 함수를 추가 후 함수를 호출하는 예제를 구현하자.
let obj3 = {};
obj3.subject = '자바스크립트 기본';
obj3.count = 8;
obj3.description = '함수와 객체에 대한 보다 자세한 내용';
obj3.display = function(){
  console.log(`교육과정: ${this.subject}`);
  console.log(`교육인원: ${this.count}`);
  console.log(`교육세부내용: ${this.description}`);
}

obj3.display();